import React from 'react'

export default function About() {
	return (
		<div className='about__container'>
			<h1 style={{textAlign: 'center', marginTop: '20px'}}>About</h1>
			<div style={{ marginTop: '20px' }}>
				Lorem ipsum dolor sit amet 	Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi a fuga quasi reiciendis maxime, necessitatibus dicta maiores quia dolore autem repellendus tenetur quos, aliquid eveniet. Veritatis dolores nam iusto neque!
				consectetur adipisicing elit. Modi a fuga	Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi a fuga quasi reiciendis maxime, necessitatibus dicta maiores quia dolore autem repellendus tenetur quos, aliquid eveniet. Veritatis dolores nam iusto neque!
				quasi reiciendis maxime, necessitatibus dicta maiores quia dolore autem repellendus tenetur quos, aliquid eveniet. Veritatis dolores nam iusto neque!
				<br /><br />
				Lorem ipsum dolor sit amet 	Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi a fuga quasi reiciendis maxime, necessitatibus dicta maiores quia dolore autem repellendus tenetur quos, aliquid eveniet. Veritatis dolores nam iusto neque!
				consectetur adipisicing elit. Modi a fuga	Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi a fuga quasi reiciendis maxime, necessitatibus dicta maiores quia dolore autem repellendus tenetur quos, aliquid eveniet. Veritatis dolores nam iusto neque!
				quasi reiciendis maxime, necessitatibus dicta maiores quia dolore autem repellendus tenetur quos, aliquid eveniet. Veritatis dolores nam iusto neque!
				<br /><br />
				Lorem ipsum dolor sit amet 	Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi a fuga quasi reiciendis maxime, necessitatibus dicta maiores quia dolore autem repellendus tenetur quos, aliquid eveniet. Veritatis dolores nam iusto neque!
				consectetur adipisicing elit. Modi a fuga 	Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi a fuga quasi reiciendis maxime, necessitatibus dicta maiores quia dolore autem repellendus tenetur quos, aliquid eveniet. Veritatis dolores nam iusto neque!
				quasi reiciendis maxime, necessitatibus dicta maiores quia dolore autem repellendus tenetur quos, aliquid eveniet. Veritatis dolores nam iusto neque!
				<br /><br />
				Lorem ipsum dolor sit amet 	Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi a fuga quasi reiciendis maxime, necessitatibus dicta maiores quia dolore autem repellendus tenetur quos, aliquid eveniet. Veritatis dolores nam iusto neque!
				consectetur adipisicing elit. Modi a fuga 	Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi a fuga quasi reiciendis maxime, necessitatibus dicta maiores quia dolore autem repellendus tenetur quos, aliquid eveniet. Veritatis dolores nam iusto neque!
				quasi reiciendis maxime, necessitatibus dicta maiores quia dolore autem repellendus tenetur quos, aliquid eveniet. Veritatis dolores nam iusto neque!
				<br /><br />
				Lorem ipsum dolor sit amet 	Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi a fuga quasi reiciendis maxime, necessitatibus dicta maiores quia dolore autem repellendus tenetur quos, aliquid eveniet. Veritatis dolores nam iusto neque!
				consectetur adipisicing elit. Modi a fuga 	Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi a fuga quasi reiciendis maxime, necessitatibus dicta maiores quia dolore autem repellendus tenetur quos, aliquid eveniet. Veritatis dolores nam iusto neque!
				quasi reiciendis maxime, necessitatibus dicta maiores quia dolore autem repellendus tenetur quos, aliquid eveniet. Veritatis dolores nam iusto neque!
				<br /><br />
				Lorem ipsum dolor sit amet 	Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi a fuga quasi reiciendis maxime, necessitatibus dicta maiores quia dolore autem repellendus tenetur quos, aliquid eveniet. Veritatis dolores nam iusto neque!
				consectetur adipisicing elit. Modi a fuga 	Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi a fuga quasi reiciendis maxime, necessitatibus dicta maiores quia dolore autem repellendus tenetur quos, aliquid eveniet. Veritatis dolores nam iusto neque!
				quasi reiciendis maxime, necessitatibus dicta maiores quia dolore autem repellendus tenetur quos, aliquid eveniet. Veritatis dolores nam iusto neque!
			</div>
		</div>
	)
}
